
version = "1.26.3"
__version__ = version
full_version = version

git_revision = "b4bf93b936802618ebb49ee43e382b576b29a0a6"
release = 'dev' not in version and '+' not in version
short_version = version.split("+")[0]
